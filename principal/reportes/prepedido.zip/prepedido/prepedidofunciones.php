<style>

    .H1{
        color:red;
    }    
</style>
<script language="JavaScript">
    function precio() {
        
        var f = document.form2;
        var factor = parseFloat(f.factor.value);	//FACTOR
//        alert(factor);
        f.text4.value = '222222';

    }
</script>