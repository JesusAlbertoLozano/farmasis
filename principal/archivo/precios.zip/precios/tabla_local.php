<?php if ($nomloc == "LOCAL0")
{
	$tabla = 's000';
}
if ($nomloc == "LOCAL1")
{
	$tabla = 's001';
}
if ($nomloc == "LOCAL2")
{
	$tabla = 's002';
}
if ($nomloc == "LOCAL3")
{
	$tabla = 's003';
}
if ($nomloc == "LOCAL4")
{
	$tabla = 's004';
}
if ($nomloc == "LOCAL5")
{
	$tabla = 's005';
}
if ($nomloc == "LOCAL6")
{
	$tabla = 's006';
}
if ($nomloc == "LOCAL7")
{
	$tabla = 's007';
}
if ($nomloc == "LOCAL8")
{
	$tabla = 's008';
}
if ($nomloc == "LOCAL9")
{
	$tabla = 's009';
}
if ($nomloc == "LOCAL10")
{
	$tabla = 's010';
}
if ($nomloc == "LOCAL11")
{
	$tabla = 's011';
}
if ($nomloc == "LOCAL12")
{
	$tabla = 's012';
}
if ($nomloc == "LOCAL13")
{
	$tabla = 's013';
}
if ($nomloc == "LOCAL14")
{
	$tabla = 's014';
}
if ($nomloc == "LOCAL15")
{
	$tabla = 's015';
}
if ($nomloc == "LOCAL16")
{
	$tabla = 's016';
}
?>